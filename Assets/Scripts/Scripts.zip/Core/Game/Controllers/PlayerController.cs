using UnityEngine;

public class PlayerController : Controller
{
}
