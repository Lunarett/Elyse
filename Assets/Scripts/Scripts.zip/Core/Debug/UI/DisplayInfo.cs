using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class DisplayInfo
{
    public static void Add(string info)
    {
        
    }

    public static void Clear()
    {
        
    }
}
